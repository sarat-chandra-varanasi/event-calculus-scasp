
gen_interference_rule_positive(Op, Block, Rule) :- 
       ds(DS),
       code(DS, Op, _, Block, Pre, _, _),
       gen_interference_predicate_positive_head(Op, Block, Pre, Pred).



gen_interference_predicate_positive_head(Operation, Block, Pre, Predicate) :-
     term_string(Operation, Op),
     term_string(Block, Bl),
     string_concat(Op, Bl, OpBlock),
     string_concat('interfere_', OpBlock, InterfereString),
     term_string(Interfere, InterfereString),
     conjunct_vars(Pre, Vars),
     generate_symbol(time, TimeSymbol),
     append(Vars, [TimeSymbol], HeadVars),
     Head =.. [Interfere|HeadVars],
     conjunct_domainvars(Pre, DomainVars),
     add_time_list(TimeSymbol, Body, Body1),
     append(DomainVars, Body1, Body2),
     Predicate = rule(head(Head),body(Body2)).
        